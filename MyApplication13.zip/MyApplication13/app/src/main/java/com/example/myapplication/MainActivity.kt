package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

// ===== MainActivity =====
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btn_fillter = findViewById<Button>(R.id.button2)
        val btn_ShowAll = findViewById<Button>(R.id.button3)

        val btn_add = findViewById<Button>(R.id.button)
        val et_item = findViewById<EditText>(R.id.editTextText)
        val lst_items = findViewById<ListView>(R.id.lst_view)
        val calendar = findViewById<CalendarView>(R.id.calendarView)
        val db = TasksDatabase.getInstance(this)
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)
        lst_items.adapter = adapter
        var selectedDate: LocalDate = LocalDate.now()

        calendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedDate = LocalDate.of(year, month + 1, dayOfMonth)
        }

        btn_add.setOnClickListener {
            val name = et_item.text.toString().trim()
            if (name.isNotEmpty()) {
                lifecycleScope.launch(Dispatchers.IO) {
                    db.taskDao().addTask(Tasks(name = name, datedb = selectedDate))
                    val allTasks = db.taskDao().getAllTasks()
                    val taskNames = allTasks.map { "${it.name} (${it.datedb})" }

                    withContext(Dispatchers.Main) {
                        adapter.clear()
                        adapter.addAll(taskNames)
                        Toast.makeText(this@MainActivity, "Task saved", Toast.LENGTH_SHORT).show()
                        et_item.text.clear()
                    }
                }
            } else {
                Toast.makeText(this, "Enter a task name", Toast.LENGTH_SHORT).show()
            }
        }




        btn_fillter.setOnClickListener {


                lifecycleScope.launch(Dispatchers.IO) {
                    val allTasksWithDate=  db.taskDao().getTasksWithDate( date = selectedDate)

                    val taskNames = allTasksWithDate.map { "${it.name} (${it.datedb})" }

                    withContext(Dispatchers.Main) {
                        adapter.clear()
                        adapter.addAll(taskNames)
                      //  Toast.makeText(this@MainActivity, "Task saved", Toast.LENGTH_SHORT).show()
                      //  et_item.text.clear()
                    }
                }

        }




        btn_ShowAll.setOnClickListener {

            lifecycleScope.launch(Dispatchers.IO) {
                val allTasksWithDate=  db.taskDao().getAllTasks()

                val taskNames = allTasksWithDate.map { "${it.name} (${it.datedb})" }

                withContext(Dispatchers.Main) {
                    adapter.clear()
                    adapter.addAll(taskNames)
                    //  Toast.makeText(this@MainActivity, "Task saved", Toast.LENGTH_SHORT).show()
                    //  et_item.text.clear()
                }
            }

        }


        lst_items.setOnItemLongClickListener { parent, view, position, id ->

            val selectedText = parent.getItemAtPosition(position).toString()

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, selectedText)
            }

            startActivity(Intent.createChooser(shareIntent, "Sharing text"))
            true
        }

    }
}

// ===== Entity =====
@Entity(tableName = "Tasks")
data class Tasks(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    var datedb: LocalDate
)

// ===== TypeConverter =====
class Converters {
    @TypeConverter
    fun fromLocalDate(date: LocalDate): String = date.toString()

    @TypeConverter
    fun toLocalDate(date: String): LocalDate = LocalDate.parse(date)
}

// ===== DAO =====
@Dao
interface taskDao {
    @Insert
    suspend fun addTask(task: Tasks)

    @Query("SELECT * FROM Tasks")
    suspend fun getAllTasks(): List<Tasks>

    @Query("SELECT * FROM Tasks WHERE datedb = :date")
    suspend fun getTasksWithDate(date: LocalDate): List<Tasks>
}

// ===== Database =====
@Database(entities = [Tasks::class], version = 1)
@TypeConverters(Converters::class)
abstract class TasksDatabase : RoomDatabase() {
    abstract fun taskDao(): taskDao

    companion object {
        @Volatile
        private var INSTANCE: TasksDatabase? = null

        fun getInstance(context: Context): TasksDatabase {
            if (INSTANCE == null) {
                synchronized(TasksDatabase::class.java) {
                    INSTANCE = Room.databaseBuilder(
                        context.applicationContext,
                        TasksDatabase::class.java,
                        "task_db"
                    ).fallbackToDestructiveMigration()
                        .build()
                }
            }
            return INSTANCE!!
        }
    }
}
